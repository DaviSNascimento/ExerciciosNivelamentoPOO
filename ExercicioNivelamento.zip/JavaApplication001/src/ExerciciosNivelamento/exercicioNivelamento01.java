package ExerciciosNivelamento;

public class exercicioNivelamento01 {

    public static void main(String[] args) {
        System.out.println("ola");
        int a = 10;
        int b = 5;
        boolean c = true;
        int resultado = (a + b) * (c ?  1 : 20);
        System.out.println(resultado);
        
        
        
    }
}
