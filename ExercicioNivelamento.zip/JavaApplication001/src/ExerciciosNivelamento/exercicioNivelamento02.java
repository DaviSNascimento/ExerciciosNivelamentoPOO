
package ExerciciosNivelamento;

public class exercicioNivelamento02 {
    public static void main(String[] args){
        System.out.println("olá");
        int x = 5;
        int y = 8;
        boolean resultado = x >= y && y != 5;
        System.out.println(resultado);
        
    }
}
