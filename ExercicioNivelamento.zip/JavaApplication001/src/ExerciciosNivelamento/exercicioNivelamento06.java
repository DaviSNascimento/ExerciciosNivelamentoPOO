
package ExerciciosNivelamento;

/**

Exercicio teorico: resposta A

 Qual é a diferença entre os comandos for, while e do-while?


Qual é a diferença entre os comandos for, while e do-while?


O comando for é executado um número fixo de vezes, enquanto o comando while é executado até que uma condição seja atendida. O comando do-while é executado pelo menos uma vez, mesmo que a condição não seja atendida.


O comando for é executado pelo menos uma vez, mesmo que a condição não seja atendida, enquanto o comando while é executado um número fixo de vezes. O comando do-while é executado até que uma condição seja atendida.


O comando for é executado até que uma condição seja atendida, enquanto o comando while é executado um número fixo de vezes. O comando do-while é executado pelo menos uma vez, mesmo que a condição não seja atendida.


O comando for é executado um número fixo de vezes, enquanto o comando while é executado pelo menos uma vez, mesmo que a condição não seja atendida. O comando do-while é executado até que uma condição não seja atendida.
 

 
 
 */
public class exercicioNivelamento06 {
    public static void main(String[] args){
        System.out.println("Resposta: A");
    }
}
