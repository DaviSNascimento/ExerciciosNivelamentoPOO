package ExerciciosNivelamento;

public class exercicioNivelamento03 {

    public static void main(String[] args) {
        System.out.println("ola");
        int x = 10;
        int y = 20;
        
        if (x > y) {
    System.out.println("x é maior que y");
} else if (x < y) {
    System.out.println("x é menor que y");
} else {
    System.out.println("x é igual a y");
}
        
        
    } 
}
