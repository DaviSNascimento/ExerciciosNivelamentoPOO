
package ExerciciosNivelamento;

public class exercicioNivelamento05 {
    public static void main(String[] args){
        System.out.println("ola");
        for (int i = 1; i <= 10; i++) {
  System.out.println(i);
}
    }
}
