
package ExerciciosNivelamento;

public class exercicioNivelamento09 {
    public static void main(String[] args){
        System.out.println("ola");
        int array[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        for (int i = 0; i < array.length; i++) {
                System.out.print("  " + array[i] + "  ");
                System.out.println("Resposta: B");
        }
    }
}
